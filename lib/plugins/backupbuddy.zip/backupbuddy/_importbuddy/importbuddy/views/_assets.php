<?php
pb_backupbuddy::load_style( 'style.css' );

pb_backupbuddy::load_script( 'jquery.js' );
pb_backupbuddy::load_script( 'ui.core.js' );
pb_backupbuddy::load_script( 'ui.widget.js' );
pb_backupbuddy::load_script( 'ui.tabs.js' );
pb_backupbuddy::load_script( 'tooltip.js' );
pb_backupbuddy::load_script( 'nprogress.js' );
pb_backupbuddy::load_script( 'importbuddy.js' );

// Tutorial
pb_backupbuddy::load_script( 'jquery.joyride-2.0.3.js' );
pb_backupbuddy::load_script( 'modernizr.mq.js' );
pb_backupbuddy::load_style( 'joyride.css' );
pb_backupbuddy::load_style( 'nprogress.css' );